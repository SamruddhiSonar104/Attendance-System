import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/class_model.dart';
import '../models/student_model.dart';
import '../models/attendance_model.dart';
import '../models/user_model.dart';

class DatabaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Get classes for a teacher
  Stream<List<ClassModel>> getTeacherClasses(String teacherId) {
    return _firestore
        .collection('classes')
        .where('teacherId', isEqualTo: teacherId)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return ClassModel.fromJson(doc.data(), doc.id);
      }).toList();
    });
  }

  // Get classes for a student
  Stream<List<ClassModel>> getStudentClasses(String studentId) {
    return _firestore
        .collection('classes')
        .where('studentIds', arrayContains: studentId)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return ClassModel.fromJson(doc.data(), doc.id);
      }).toList();
    });
  }

  // Get all students in a class
  Future<List<StudentModel>> getStudentsInClass(String classId) async {
    try {
      DocumentSnapshot classDoc = await _firestore.collection('classes').doc(classId).get();
      
      if (classDoc.exists) {
        List<String> studentIds = List<String>.from((classDoc.data() as Map<String, dynamic>)['studentIds'] ?? []);
        
        if (studentIds.isEmpty) return [];
        
        List<StudentModel> students = [];
        
        for (var studentId in studentIds) {
          DocumentSnapshot userDoc = await _firestore.collection('users').doc(studentId).get();
          
          if (userDoc.exists) {
            students.add(StudentModel(
              id: userDoc.id,
              name: (userDoc.data() as Map<String, dynamic>)['name'] ?? '',
              email: (userDoc.data() as Map<String, dynamic>)['email'] ?? '',
              rollNumber: (userDoc.data() as Map<String, dynamic>)['rollNumber'] ?? '',
            ));
          }
        }
        
        return students;
      }
      return [];
    } catch (e) {
      print('Error getting students in class: $e');
      return [];
    }
  }

  // Save attendance record
  Future<void> saveAttendance(AttendanceRecord record) async {
    try {
      // Check if attendance for this class on this date already exists
      QuerySnapshot existingRecords = await _firestore
          .collection('attendance')
          .where('classId', isEqualTo: record.classId)
          .where('date', isEqualTo: record.date.toIso8601String())
          .get();

      if (existingRecords.docs.isNotEmpty) {
        // Update existing record
        await _firestore
            .collection('attendance')
            .doc(existingRecords.docs.first.id)
            .update(record.toJson());
      } else {
        // Create new record
        await _firestore.collection('attendance').add(record.toJson());
      }
    } catch (e) {
      print('Error saving attendance: $e');
      rethrow;
    }
  }

  // Get attendance history for a class
  Stream<List<AttendanceRecord>> getAttendanceForClass(String classId) {
    return _firestore
        .collection('attendance')
        .where('classId', isEqualTo: classId)
        .orderBy('date', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs.map((doc) {
        return AttendanceRecord.fromJson(doc.data(), doc.id);
      }).toList();
    });
  }

  // Get attendance for a student
  Stream<List<AttendanceRecord>> getAttendanceForStudent(String studentId) {
    return _firestore
        .collection('attendance')
        .snapshots()
        .map((snapshot) {
      List<AttendanceRecord> records = [];
      
      for (var doc in snapshot.docs) {
        AttendanceRecord record = AttendanceRecord.fromJson(doc.data(), doc.id);
        bool studentPresent = record.studentAttendances.any((attendance) => attendance.studentId == studentId);
        
        if (studentPresent) {
          records.add(record);
        }
      }
      
      return records;
    });
  }

  // Check if attendance has been taken for a class on a specific date
  Future<bool> isAttendanceTakenForDate(String classId, DateTime date) async {
    try {
      QuerySnapshot snapshot = await _firestore
          .collection('attendance')
          .where('classId', isEqualTo: classId)
          .where('date', isEqualTo: date.toIso8601String())
          .get();
      
      return snapshot.docs.isNotEmpty;
    } catch (e) {
      print('Error checking attendance status: $e');
      return false;
    }
  }
}
