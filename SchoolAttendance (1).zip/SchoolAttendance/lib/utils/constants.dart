import 'package:flutter/material.dart';

// Colors
const Color primaryColor = Colors.blue;
const Color secondaryColor = Colors.blueAccent;
const Color accentColor = Color(0xFF42A5F5);

// Text Styles
const TextStyle headingStyle = TextStyle(
  fontSize: 24,
  fontWeight: FontWeight.bold,
  color: Colors.black87,
);

const TextStyle subheadingStyle = TextStyle(
  fontSize: 18,
  fontWeight: FontWeight.w500,
  color: Colors.black87,
);

const TextStyle bodyTextStyle = TextStyle(
  fontSize: 14,
  color: Colors.black87,
);

// Error Messages
const String authErrorMessage = 'Authentication failed. Please try again.';
const String networkErrorMessage = 'Network error. Please check your connection.';

// Firebase Collection Names
const String usersCollection = 'users';
const String classesCollection = 'classes';
const String attendanceCollection = 'attendance';

// Spacing
const double defaultPadding = 16.0;
const double smallPadding = 8.0;
const double largePadding = 24.0;

// Durations
const Duration snackBarDuration = Duration(seconds: 3);
const Duration animationDuration = Duration(milliseconds: 300);
