String? validateEmail(String? value) {
  if (value == null || value.isEmpty) {
    return 'Email is required';
  }
  
  final emailRegex = RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
  
  if (!emailRegex.hasMatch(value)) {
    return 'Please enter a valid email address';
  }
  
  return null;
}

String? validatePassword(String? value) {
  if (value == null || value.isEmpty) {
    return 'Password is required';
  }
  
  if (value.length < 6) {
    return 'Password must be at least 6 characters';
  }
  
  return null;
}

String? validateName(String? value) {
  if (value == null || value.isEmpty) {
    return 'Name is required';
  }
  
  return null;
}

String? validateRollNumber(String? value) {
  if (value == null || value.isEmpty) {
    return 'Roll number is required';
  }
  
  return null;
}

String? validateClassName(String? value) {
  if (value == null || value.isEmpty) {
    return 'Class name is required';
  }
  
  return null;
}

String? validateSubject(String? value) {
  if (value == null || value.isEmpty) {
    return 'Subject is required';
  }
  
  return null;
}

String? validateSection(String? value) {
  if (value == null || value.isEmpty) {
    return 'Section is required';
  }
  
  return null;
}
