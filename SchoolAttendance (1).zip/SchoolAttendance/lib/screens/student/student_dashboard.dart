import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/auth_provider.dart';
import '../../providers/class_provider.dart';
import '../../providers/attendance_provider.dart';
import '../../models/attendance_model.dart';
import '../../widgets/loading_indicator.dart';

class StudentDashboard extends StatefulWidget {
  const StudentDashboard({Key? key}) : super(key: key);

  @override
  _StudentDashboardState createState() => _StudentDashboardState();
}

class _StudentDashboardState extends State<StudentDashboard> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    
    Future.microtask(() {
      Provider.of<AttendanceProvider>(context, listen: false).fetchStudentAttendance();
    });
  }
  
  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final classProvider = Provider.of<ClassProvider>(context);
    final attendanceProvider = Provider.of<AttendanceProvider>(context);
    
    final user = authProvider.user;
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Student Dashboard'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Overview'),
            Tab(text: 'Classes'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await authProvider.signOut();
            },
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildOverviewTab(authProvider, attendanceProvider),
          _buildClassesTab(classProvider),
        ],
      ),
    );
  }

  Widget _buildOverviewTab(AuthProvider authProvider, AttendanceProvider attendanceProvider) {
    final user = authProvider.user;
    final studentAttendance = attendanceProvider.studentAttendance;
    
    if (attendanceProvider.isLoading) {
      return const LoadingIndicator();
    }
    
    // Calculate overview statistics
    final totalClasses = studentAttendance.length;
    final attendedClasses = studentAttendance
        .where((record) => record.studentAttendances
            .any((attendance) => attendance.studentId == user?.uid && attendance.isPresent))
        .length;
    
    final attendancePercentage = totalClasses > 0
        ? (attendedClasses / totalClasses) * 100
        : 0;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Hello, ${user?.name ?? "Student"}',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  if (user?.rollNumber != null)
                    Text(
                      'Roll Number: ${user!.rollNumber}',
                      style: const TextStyle(fontSize: 16),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Attendance Summary',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatCard('Total Classes', totalClasses.toString()),
                      _buildStatCard('Present', attendedClasses.toString()),
                      _buildStatCard('Absent', (totalClasses - attendedClasses).toString()),
                    ],
                  ),
                  const SizedBox(height: 16),
                  LinearProgressIndicator(
                    value: attendancePercentage / 100,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      attendancePercentage >= 75 ? Colors.green : Colors.red,
                    ),
                    minHeight: 10,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Attendance Rate: ${attendancePercentage.toStringAsFixed(1)}%',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: attendancePercentage >= 75 ? Colors.green : Colors.red,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Recent Attendance',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          studentAttendance.isEmpty
              ? const Card(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Center(
                      child: Text('No attendance records found'),
                    ),
                  ),
                )
              : _buildRecentAttendance(studentAttendance, user?.uid ?? ''),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentAttendance(List<AttendanceRecord> records, String studentId) {
    // Sort by date (most recent first) and limit to last 10
    final recentRecords = List<AttendanceRecord>.from(records)
      ..sort((a, b) => b.date.compareTo(a.date));
    
    final displayRecords = recentRecords.take(10).toList();
    
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: displayRecords.length,
      itemBuilder: (context, index) {
        final record = displayRecords[index];
        final studentAttendance = record.studentAttendances
            .firstWhere((a) => a.studentId == studentId, orElse: () => 
              StudentAttendance(
                studentId: studentId, 
                studentName: '',
                rollNumber: '', 
                isPresent: false
              )
            );
        
        return Card(
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            title: Text(
              DateFormat('EEEE, dd MMM yyyy').format(record.date),
            ),
            subtitle: Text(record.className),
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: studentAttendance.isPresent ? Colors.green.shade100 : Colors.red.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                studentAttendance.isPresent ? 'Present' : 'Absent',
                style: TextStyle(
                  color: studentAttendance.isPresent ? Colors.green.shade800 : Colors.red.shade800,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildClassesTab(ClassProvider classProvider) {
    final classes = classProvider.classes;
    
    if (classProvider.isLoading) {
      return const LoadingIndicator();
    }
    
    if (classes.isEmpty) {
      return const Center(
        child: Text('You are not enrolled in any classes'),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: classes.length,
      itemBuilder: (context, index) {
        final classModel = classes[index];
        
        return Card(
          margin: const EdgeInsets.only(bottom: 16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  classModel.name,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text('Subject: ${classModel.subject}'),
                Text('Section: ${classModel.section}'),
                const SizedBox(height: 4),
                Text('Teacher: ${classModel.teacherName}'),
              ],
            ),
          ),
        );
      },
    );
  }
}
