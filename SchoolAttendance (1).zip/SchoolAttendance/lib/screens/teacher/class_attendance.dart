import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/class_provider.dart';
import '../../providers/attendance_provider.dart';
import '../../models/class_model.dart';
import '../../models/student_model.dart';
import '../../widgets/loading_indicator.dart';

class ClassAttendanceScreen extends StatefulWidget {
  final ClassModel classModel;

  const ClassAttendanceScreen({Key? key, required this.classModel}) : super(key: key);

  @override
  _ClassAttendanceScreenState createState() => _ClassAttendanceScreenState();
}

class _ClassAttendanceScreenState extends State<ClassAttendanceScreen> {
  DateTime _selectedDate = DateTime.now();
  bool _isInit = false;
  bool _attendanceAlreadyTaken = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_isInit) {
      _initializeAttendance();
      _isInit = true;
    }
  }

  Future<void> _initializeAttendance() async {
    final classProvider = Provider.of<ClassProvider>(context, listen: false);
    final attendanceProvider = Provider.of<AttendanceProvider>(context, listen: false);
    
    // Check if attendance is already taken for today
    bool isTaken = await attendanceProvider.isAttendanceTakenToday(widget.classModel.id);
    
    if (mounted) {
      setState(() {
        _attendanceAlreadyTaken = isTaken;
      });
    }
    
    // Fetch students if not already loaded
    List<StudentModel> students = classProvider.getStudentsForClass(widget.classModel.id);
    if (students.isEmpty) {
      await classProvider.fetchStudentsInClass(widget.classModel.id);
      students = classProvider.getStudentsForClass(widget.classModel.id);
    }
    
    // Initialize attendance sheet
    attendanceProvider.initializeAttendanceSheet(widget.classModel.id, students);
  }

  @override
  Widget build(BuildContext context) {
    final classProvider = Provider.of<ClassProvider>(context);
    final attendanceProvider = Provider.of<AttendanceProvider>(context);
    
    final students = classProvider.getStudentsForClass(widget.classModel.id);
    final attendanceList = attendanceProvider.currentAttendanceMap[widget.classModel.id] ?? [];
    
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.classModel.name} Attendance'),
      ),
      body: classProvider.isLoading || attendanceProvider.isLoading
          ? const LoadingIndicator()
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Date: ${DateFormat('dd MMM yyyy').format(_selectedDate)}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.calendar_today),
                        onPressed: () => _selectDate(context),
                      ),
                    ],
                  ),
                ),
                if (_attendanceAlreadyTaken)
                  Container(
                    color: Colors.amber.shade100,
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        const Icon(Icons.warning, color: Colors.amber),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Attendance has already been taken for ${DateFormat('dd MMM yyyy').format(_selectedDate)}. Submitting again will overwrite the previous record.',
                            style: const TextStyle(
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                Expanded(
                  child: students.isEmpty
                      ? const Center(child: Text('No students in this class'))
                      : ListView.builder(
                          itemCount: students.length,
                          itemBuilder: (context, index) {
                            final student = students[index];
                            
                            // Find the corresponding attendance entry
                            final attendanceEntry = attendanceList.firstWhere(
                              (a) => a.studentId == student.id,
                              orElse: () => attendanceProvider.currentAttendanceMap[widget.classModel.id]![index],
                            );
                            
                            return Card(
                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                              child: ListTile(
                                leading: CircleAvatar(
                                  child: Text(student.name.substring(0, 1).toUpperCase()),
                                ),
                                title: Text(student.name),
                                subtitle: Text('Roll No: ${student.rollNumber}'),
                                trailing: Switch(
                                  value: attendanceEntry.isPresent,
                                  onChanged: (value) {
                                    attendanceProvider.updateAttendanceStatus(
                                      widget.classModel.id,
                                      student.id,
                                      value,
                                    );
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                    ),
                    onPressed: attendanceList.isEmpty
                        ? null
                        : () => _submitAttendance(context, attendanceProvider),
                    child: const Text('Submit Attendance'),
                  ),
                ),
              ],
            ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now().subtract(const Duration(days: 30)),
      lastDate: DateTime.now(),
    );
    
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
      
      // Check if attendance is already taken for the selected date
      final attendanceProvider = Provider.of<AttendanceProvider>(context, listen: false);
      bool isTaken = await attendanceProvider.isAttendanceTakenForDate(
        widget.classModel.id, 
        _selectedDate,
      );
      
      setState(() {
        _attendanceAlreadyTaken = isTaken;
      });
    }
  }

  Future<void> _submitAttendance(BuildContext context, AttendanceProvider attendanceProvider) async {
    try {
      await attendanceProvider.submitAttendance(widget.classModel, _selectedDate);
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Attendance submitted successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        
        // Go back to the dashboard
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error submitting attendance: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}
