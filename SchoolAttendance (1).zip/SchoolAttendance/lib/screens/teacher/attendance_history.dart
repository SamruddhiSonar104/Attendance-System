import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../providers/attendance_provider.dart';
import '../../providers/class_provider.dart';
import '../../models/attendance_model.dart';
import '../../widgets/loading_indicator.dart';

class AttendanceHistoryScreen extends StatefulWidget {
  final String classId;

  const AttendanceHistoryScreen({Key? key, required this.classId}) : super(key: key);

  @override
  _AttendanceHistoryScreenState createState() => _AttendanceHistoryScreenState();
}

class _AttendanceHistoryScreenState extends State<AttendanceHistoryScreen> {
  @override
  void initState() {
    super.initState();
    Future.microtask(() {
      Provider.of<AttendanceProvider>(context, listen: false)
          .fetchAttendanceForClass(widget.classId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final attendanceProvider = Provider.of<AttendanceProvider>(context);
    final classProvider = Provider.of<ClassProvider>(context);
    
    final classModel = classProvider.getClassById(widget.classId);
    final attendanceRecords = attendanceProvider.classAttendance[widget.classId] ?? [];
    
    return Scaffold(
      appBar: AppBar(
        title: Text('${classModel?.name ?? "Class"} Attendance History'),
      ),
      body: attendanceProvider.isLoading
          ? const LoadingIndicator()
          : attendanceRecords.isEmpty
              ? const Center(child: Text('No attendance records found'))
              : ListView.builder(
                  itemCount: attendanceRecords.length,
                  itemBuilder: (context, index) {
                    final record = attendanceRecords[index];
                    
                    // Calculate attendance statistics
                    int totalStudents = record.studentAttendances.length;
                    int presentStudents = record.studentAttendances
                        .where((attendance) => attendance.isPresent)
                        .length;
                    double attendancePercentage = totalStudents > 0
                        ? (presentStudents / totalStudents) * 100
                        : 0;
                    
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: ExpansionTile(
                        title: Text(
                          DateFormat('EEEE, dd MMM yyyy').format(record.date),
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          'Present: $presentStudents/$totalStudents (${attendancePercentage.toStringAsFixed(1)}%)',
                        ),
                        children: [
                          _buildAttendanceDetails(record),
                        ],
                      ),
                    );
                  },
                ),
    );
  }

  Widget _buildAttendanceDetails(AttendanceRecord record) {
    // Sort students by roll number
    final sortedAttendances = List<StudentAttendance>.from(record.studentAttendances)
      ..sort((a, b) => a.rollNumber.compareTo(b.rollNumber));
    
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        children: [
          const Divider(),
          Row(
            children: const [
              Expanded(
                flex: 2,
                child: Text(
                  'Roll No',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                flex: 4,
                child: Text(
                  'Name',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                flex: 2,
                child: Text(
                  'Status',
                  style: TextStyle(fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
          const Divider(),
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: sortedAttendances.length,
            itemBuilder: (context, index) {
              final attendance = sortedAttendances[index];
              
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: Text(attendance.rollNumber),
                    ),
                    Expanded(
                      flex: 4,
                      child: Text(attendance.studentName),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        alignment: Alignment.center,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: attendance.isPresent ? Colors.green.shade100 : Colors.red.shade100,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          attendance.isPresent ? 'Present' : 'Absent',
                          style: TextStyle(
                            color: attendance.isPresent ? Colors.green.shade800 : Colors.red.shade800,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
