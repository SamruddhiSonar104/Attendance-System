import 'package:flutter/material.dart';
import '../models/class_model.dart';
import '../models/student_model.dart';
import '../models/user_model.dart';
import '../services/database_service.dart';

class ClassProvider with ChangeNotifier {
  final DatabaseService _databaseService = DatabaseService();
  UserModel? _user;
  
  List<ClassModel> _classes = [];
  bool _isLoading = false;
  Map<String, List<StudentModel>> _studentsInClass = {};

  List<ClassModel> get classes => _classes;
  bool get isLoading => _isLoading;
  Map<String, List<StudentModel>> get studentsInClass => _studentsInClass;

  ClassProvider(this._user) {
    if (_user != null) {
      _fetchClasses();
    }
  }

  void _fetchClasses() {
    _isLoading = true;
    notifyListeners();

    if (_user!.role == UserRole.teacher) {
      _databaseService.getTeacherClasses(_user!.uid).listen((classesList) {
        _classes = classesList;
        _isLoading = false;
        notifyListeners();
        
        // Fetch students for each class
        for (var classModel in _classes) {
          fetchStudentsInClass(classModel.id);
        }
      });
    } else {
      _databaseService.getStudentClasses(_user!.uid).listen((classesList) {
        _classes = classesList;
        _isLoading = false;
        notifyListeners();
      });
    }
  }

  Future<void> fetchStudentsInClass(String classId) async {
    try {
      List<StudentModel> students = await _databaseService.getStudentsInClass(classId);
      _studentsInClass[classId] = students;
      notifyListeners();
    } catch (e) {
      print('Error fetching students: $e');
    }
  }

  // Get a specific class by ID
  ClassModel? getClassById(String classId) {
    try {
      return _classes.firstWhere((classModel) => classModel.id == classId);
    } catch (e) {
      return null;
    }
  }

  // Get students for a specific class
  List<StudentModel> getStudentsForClass(String classId) {
    return _studentsInClass[classId] ?? [];
  }
}
