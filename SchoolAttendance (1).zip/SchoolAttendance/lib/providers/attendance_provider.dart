import 'package:flutter/material.dart';
import '../models/attendance_model.dart';
import '../models/student_model.dart';
import '../models/user_model.dart';
import '../models/class_model.dart';
import '../services/database_service.dart';

class AttendanceProvider with ChangeNotifier {
  final DatabaseService _databaseService = DatabaseService();
  UserModel? _user;
  
  Map<String, List<AttendanceRecord>> _classAttendance = {};
  List<AttendanceRecord> _studentAttendance = [];
  bool _isLoading = false;
  Map<String, List<StudentAttendance>> _currentAttendanceMap = {};

  Map<String, List<AttendanceRecord>> get classAttendance => _classAttendance;
  List<AttendanceRecord> get studentAttendance => _studentAttendance;
  bool get isLoading => _isLoading;
  Map<String, List<StudentAttendance>> get currentAttendanceMap => _currentAttendanceMap;

  AttendanceProvider(this._user);

  // Fetch attendance for a specific class
  void fetchAttendanceForClass(String classId) {
    _isLoading = true;
    notifyListeners();

    _databaseService.getAttendanceForClass(classId).listen((records) {
      _classAttendance[classId] = records;
      _isLoading = false;
      notifyListeners();
    });
  }

  // Fetch attendance for the current student
  void fetchStudentAttendance() {
    if (_user != null && _user!.role == UserRole.student) {
      _isLoading = true;
      notifyListeners();

      _databaseService.getAttendanceForStudent(_user!.uid).listen((records) {
        _studentAttendance = records;
        _isLoading = false;
        notifyListeners();
      });
    }
  }

  // Initialize attendance sheet for a class
  void initializeAttendanceSheet(String classId, List<StudentModel> students) {
    List<StudentAttendance> attendances = students.map((student) {
      return StudentAttendance(
        studentId: student.id,
        studentName: student.name,
        rollNumber: student.rollNumber,
        isPresent: false,
      );
    }).toList();
    
    _currentAttendanceMap[classId] = attendances;
    notifyListeners();
  }

  // Update attendance status for a student
  void updateAttendanceStatus(String classId, String studentId, bool isPresent) {
    if (_currentAttendanceMap.containsKey(classId)) {
      final index = _currentAttendanceMap[classId]!.indexWhere(
        (attendance) => attendance.studentId == studentId,
      );
      
      if (index != -1) {
        _currentAttendanceMap[classId]![index] = _currentAttendanceMap[classId]![index].copyWith(
          isPresent: isPresent,
        );
        notifyListeners();
      }
    }
  }

  // Submit attendance for a class
  Future<void> submitAttendance(ClassModel classModel, DateTime date) async {
    try {
      _isLoading = true;
      notifyListeners();
      
      if (_currentAttendanceMap.containsKey(classModel.id) && _user != null) {
        AttendanceRecord record = AttendanceRecord(
          id: '',  // Firestore will generate this
          classId: classModel.id,
          className: classModel.name,
          date: date,
          studentAttendances: _currentAttendanceMap[classModel.id]!,
          teacherId: _user!.uid,
        );
        
        await _databaseService.saveAttendance(record);
        
        // Reset current attendance after submission
        _currentAttendanceMap.remove(classModel.id);
      }
      
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      rethrow;
    }
  }

  // Check if attendance is already taken for this class today
  Future<bool> isAttendanceTakenToday(String classId) async {
    DateTime today = DateTime.now();
    DateTime dateToCheck = DateTime(today.year, today.month, today.day);
    return await _databaseService.isAttendanceTakenForDate(classId, dateToCheck);
  }

  // Get attendance for a specific date and class
  AttendanceRecord? getAttendanceForDate(String classId, DateTime date) {
    if (_classAttendance.containsKey(classId)) {
      try {
        return _classAttendance[classId]!.firstWhere(
          (record) => isSameDay(record.date, date),
        );
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  // Helper function to check if two dates are the same day
  bool isSameDay(DateTime date1, DateTime date2) {
    return date1.year == date2.year && 
           date1.month == date2.month && 
           date1.day == date2.day;
  }
}
