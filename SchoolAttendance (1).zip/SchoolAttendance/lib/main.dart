import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Attendance Management System',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        useMaterial3: true,
      ),
      home: const DemoLoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class DemoLoginScreen extends StatefulWidget {
  const DemoLoginScreen({Key? key}) : super(key: key);

  @override
  State<DemoLoginScreen> createState() => _DemoLoginScreenState();
}

class _DemoLoginScreenState extends State<DemoLoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _obscurePassword = true;
  bool _isLoading = false;
  String _errorMessage = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(
                      Icons.school,
                      size: 80,
                      color: Colors.blue,
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'Attendance Management',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 48),
                    TextFormField(
                      controller: _emailController,
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email),
                        border: OutlineInputBorder(),
                      ),
                      keyboardType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Email is required';
                        }
                        final emailRegex = RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$');
                        if (!emailRegex.hasMatch(value)) {
                          return 'Please enter a valid email address';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _passwordController,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(Icons.lock),
                        border: const OutlineInputBorder(),
                        suffixIcon: IconButton(
                          icon: Icon(_obscurePassword ? Icons.visibility : Icons.visibility_off),
                          onPressed: () {
                            setState(() {
                              _obscurePassword = !_obscurePassword;
                            });
                          },
                        ),
                      ),
                      obscureText: _obscurePassword,
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Password is required';
                        }
                        if (value.length < 6) {
                          return 'Password must be at least 6 characters';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    if (_errorMessage.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16.0),
                        child: Text(
                          _errorMessage,
                          style: const TextStyle(
                            color: Colors.red,
                            fontSize: 14,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    _isLoading
                        ? const Center(child: CircularProgressIndicator())
                        : ElevatedButton(
                            onPressed: _handleDemo,
                            style: ElevatedButton.styleFrom(
                              minimumSize: const Size.fromHeight(50),
                            ),
                            child: const Text('Sign In (Demo)'),
                          ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        TextButton(
                          onPressed: () {
                            _emailController.text = 'teacher@example.com';
                            _passwordController.text = 'password';
                          },
                          child: const Text('Teacher Demo'),
                        ),
                        const SizedBox(width: 16),
                        TextButton(
                          onPressed: () {
                            _emailController.text = 'student@example.com';
                            _passwordController.text = 'password';
                          },
                          child: const Text('Student Demo'),
                        ),
                      ],
                    ),
                    TextButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (context) => AlertDialog(
                            title: const Text('Reset Password'),
                            content: TextFormField(
                              decoration: const InputDecoration(
                                labelText: 'Email',
                                prefixIcon: Icon(Icons.email),
                                border: OutlineInputBorder(),
                              ),
                              keyboardType: TextInputType.emailAddress,
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: const Text('Cancel'),
                              ),
                              TextButton(
                                onPressed: () {
                                  Navigator.pop(context);
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Password reset email sent!'),
                                    ),
                                  );
                                },
                                child: const Text('Reset'),
                              ),
                            ],
                          ),
                        );
                      },
                      child: const Text('Forgot Password?'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
  
  void _handleDemo() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
        _errorMessage = '';
      });
      
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));
      
      final email = _emailController.text.trim().toLowerCase();
      
      if (email == 'teacher@example.com') {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const TeacherDashboardDemo())
        );
      } else if (email == 'student@example.com') {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const StudentDashboardDemo())
        );
      } else {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Invalid credentials. Try teacher@example.com or student@example.com with password: password';
        });
      }
    }
  }
}

// Demo Teacher Dashboard
class TeacherDashboardDemo extends StatelessWidget {
  const TeacherDashboardDemo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Teacher Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const DemoLoginScreen())
              );
            },
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 4,
        itemBuilder: (context, index) {
          final classes = [
            {'name': 'Mathematics - Class 10', 'subject': 'Mathematics', 'section': 'A', 'students': 35},
            {'name': 'Physics - Class A', 'subject': 'Physics', 'section': 'B', 'students': 28},
            {'name': 'Chemistry Lab', 'subject': 'Chemistry', 'section': 'A', 'students': 32},
            {'name': 'Computer Science', 'subject': 'CS', 'section': 'C', 'students': 25},
          ];
          
          final classModel = classes[index];
          
          return Card(
            elevation: 2,
            margin: const EdgeInsets.only(bottom: 16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    classModel['name'] as String,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('Subject: ${classModel['subject']}'),
                  Text('Section: ${classModel['section']}'),
                  Text('Students: ${classModel['students']}'),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton.icon(
                        icon: const Icon(Icons.edit),
                        label: const Text('Mark Attendance'),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ClassAttendanceDemo(className: classModel['name'] as String),
                            ),
                          );
                        },
                      ),
                      ElevatedButton.icon(
                        icon: const Icon(Icons.history),
                        label: const Text('History'),
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => AttendanceHistoryDemo(className: classModel['name'] as String),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// Demo Student Dashboard
class StudentDashboardDemo extends StatelessWidget {
  const StudentDashboardDemo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Student Dashboard'),
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              onPressed: () {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => const DemoLoginScreen())
                );
              },
            ),
          ],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Overview'),
              Tab(text: 'Classes'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            // Overview Tab
            SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text(
                            'Hello, John Smith',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Roll Number: ST12345',
                            style: TextStyle(fontSize: 16),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Attendance Summary',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 16),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              _buildStatCard('Total Classes', '42'),
                              _buildStatCard('Present', '38'),
                              _buildStatCard('Absent', '4'),
                            ],
                          ),
                          const SizedBox(height: 16),
                          const LinearProgressIndicator(
                            value: 0.905, // 38/42 = 90.5%
                            backgroundColor: Colors.grey,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
                            minHeight: 10,
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            'Attendance Rate: 90.5%',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Recent Attendance',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: 5,
                    itemBuilder: (context, index) {
                      final records = [
                        {'date': 'Monday, 19 Apr 2025', 'class': 'Mathematics - Class 10', 'status': true},
                        {'date': 'Monday, 19 Apr 2025', 'class': 'Physics - Class A', 'status': true},
                        {'date': 'Monday, 19 Apr 2025', 'class': 'Chemistry Lab', 'status': true},
                        {'date': 'Friday, 16 Apr 2025', 'class': 'Computer Science', 'status': false},
                        {'date': 'Friday, 16 Apr 2025', 'class': 'Mathematics - Class 10', 'status': true},
                      ];
                      
                      final record = records[index];
                      final isPresent = record['status'] as bool;
                      
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          title: Text(record['date'] as String),
                          subtitle: Text(record['class'] as String),
                          trailing: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: isPresent ? Colors.green.shade100 : Colors.red.shade100,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              isPresent ? 'Present' : 'Absent',
                              style: TextStyle(
                                color: isPresent ? Colors.green.shade800 : Colors.red.shade800,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            
            // Classes Tab
            ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: 4,
              itemBuilder: (context, index) {
                final classes = [
                  {'name': 'Mathematics - Class 10', 'subject': 'Mathematics', 'section': 'A', 'teacher': 'Mr. John Smith'},
                  {'name': 'Physics - Class A', 'subject': 'Physics', 'section': 'B', 'teacher': 'Dr. Robert Brown'},
                  {'name': 'Chemistry Lab', 'subject': 'Chemistry', 'section': 'A', 'teacher': 'Mrs. Emily White'},
                  {'name': 'Computer Science', 'subject': 'CS', 'section': 'C', 'teacher': 'Mr. David Miller'},
                ];
                
                final classModel = classes[index];
                
                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          classModel['name'] as String,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text('Subject: ${classModel['subject']}'),
                        Text('Section: ${classModel['section']}'),
                        const SizedBox(height: 4),
                        Text('Teacher: ${classModel['teacher']}'),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildStatCard(String title, String value) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Demo for Class Attendance Screen
class ClassAttendanceDemo extends StatefulWidget {
  final String className;
  
  const ClassAttendanceDemo({Key? key, required this.className}) : super(key: key);

  @override
  State<ClassAttendanceDemo> createState() => _ClassAttendanceDemoState();
}

class _ClassAttendanceDemoState extends State<ClassAttendanceDemo> {
  DateTime _selectedDate = DateTime.now();
  bool _attendanceAlreadyTaken = false;
  List<Map<String, dynamic>> _students = [];
  
  @override
  void initState() {
    super.initState();
    // Demo data
    _students = [
      {'id': '1', 'name': 'Alice Johnson', 'rollNo': '1001', 'isPresent': false},
      {'id': '2', 'name': 'Bob Smith', 'rollNo': '1002', 'isPresent': false},
      {'id': '3', 'name': 'Charlie Brown', 'rollNo': '1003', 'isPresent': false},
      {'id': '4', 'name': 'Diana Ross', 'rollNo': '1004', 'isPresent': false},
      {'id': '5', 'name': 'Edward Norton', 'rollNo': '1005', 'isPresent': false},
      {'id': '6', 'name': 'Fiona Apple', 'rollNo': '1006', 'isPresent': false},
      {'id': '7', 'name': 'George Lucas', 'rollNo': '1007', 'isPresent': false},
      {'id': '8', 'name': 'Helen Hunt', 'rollNo': '1008', 'isPresent': false},
    ];
  }
  
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now().subtract(const Duration(days: 30)),
      lastDate: DateTime.now(),
    );
    
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _attendanceAlreadyTaken = false;
      });
    }
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.className} Attendance'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Date: ${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: () => _selectDate(context),
                ),
              ],
            ),
          ),
          if (_attendanceAlreadyTaken)
            Container(
              color: Colors.amber.shade100,
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.warning, color: Colors.amber),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Attendance has already been taken for this date. Submitting again will overwrite the previous record.',
                      style: const TextStyle(
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          Expanded(
            child: ListView.builder(
              itemCount: _students.length,
              itemBuilder: (context, index) {
                final student = _students[index];
                
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Text(student['name'].toString().substring(0, 1).toUpperCase()),
                    ),
                    title: Text(student['name']),
                    subtitle: Text('Roll No: ${student['rollNo']}'),
                    trailing: Switch(
                      value: student['isPresent'],
                      onChanged: (value) {
                        setState(() {
                          _students[index]['isPresent'] = value;
                        });
                      },
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
              onPressed: () {
                // Simulate saving the attendance
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Attendance submitted successfully!'),
                    backgroundColor: Colors.green,
                  ),
                );
                
                Navigator.pop(context);
              },
              child: const Text('Submit Attendance'),
            ),
          ),
        ],
      ),
    );
  }
}

// Demo for Attendance History Screen
class AttendanceHistoryDemo extends StatelessWidget {
  final String className;
  
  const AttendanceHistoryDemo({Key? key, required this.className}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Demo attendance records
    final List<Map<String, dynamic>> attendanceRecords = [
      {
        'date': 'Monday, 19 Apr 2025',
        'present': 32,
        'total': 35,
        'students': [
          {'rollNo': '1001', 'name': 'Alice Johnson', 'isPresent': true},
          {'rollNo': '1002', 'name': 'Bob Smith', 'isPresent': true},
          {'rollNo': '1003', 'name': 'Charlie Brown', 'isPresent': false},
          {'rollNo': '1004', 'name': 'Diana Ross', 'isPresent': true},
          {'rollNo': '1005', 'name': 'Edward Norton', 'isPresent': true},
        ]
      },
      {
        'date': 'Friday, 16 Apr 2025',
        'present': 30,
        'total': 35,
        'students': [
          {'rollNo': '1001', 'name': 'Alice Johnson', 'isPresent': true},
          {'rollNo': '1002', 'name': 'Bob Smith', 'isPresent': false},
          {'rollNo': '1003', 'name': 'Charlie Brown', 'isPresent': true},
          {'rollNo': '1004', 'name': 'Diana Ross', 'isPresent': true},
          {'rollNo': '1005', 'name': 'Edward Norton', 'isPresent': false},
        ]
      },
      {
        'date': 'Wednesday, 14 Apr 2025',
        'present': 33,
        'total': 35,
        'students': [
          {'rollNo': '1001', 'name': 'Alice Johnson', 'isPresent': true},
          {'rollNo': '1002', 'name': 'Bob Smith', 'isPresent': true},
          {'rollNo': '1003', 'name': 'Charlie Brown', 'isPresent': true},
          {'rollNo': '1004', 'name': 'Diana Ross', 'isPresent': true},
          {'rollNo': '1005', 'name': 'Edward Norton', 'isPresent': false},
        ]
      },
    ];
    
    return Scaffold(
      appBar: AppBar(
        title: Text('$className Attendance History'),
      ),
      body: ListView.builder(
        itemCount: attendanceRecords.length,
        itemBuilder: (context, index) {
          final record = attendanceRecords[index];
          final presentStudents = record['present'] as int;
          final totalStudents = record['total'] as int;
          final attendancePercentage = (presentStudents / totalStudents) * 100;
          
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ExpansionTile(
              title: Text(
                record['date'] as String,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Present: $presentStudents/$totalStudents (${attendancePercentage.toStringAsFixed(1)}%)',
              ),
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Column(
                    children: [
                      const Divider(),
                      Row(
                        children: const [
                          Expanded(
                            flex: 2,
                            child: Text(
                              'Roll No',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Expanded(
                            flex: 4,
                            child: Text(
                              'Name',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                          Expanded(
                            flex: 2,
                            child: Text(
                              'Status',
                              style: TextStyle(fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                      const Divider(),
                      ListView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: (record['students'] as List).length,
                        itemBuilder: (context, studentIndex) {
                          final student = (record['students'] as List)[studentIndex] as Map<String, dynamic>;
                          final isPresent = student['isPresent'] as bool;
                          
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: Text(student['rollNo'] as String),
                                ),
                                Expanded(
                                  flex: 4,
                                  child: Text(student['name'] as String),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Container(
                                    alignment: Alignment.center,
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: isPresent ? Colors.green.shade100 : Colors.red.shade100,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Text(
                                      isPresent ? 'Present' : 'Absent',
                                      style: TextStyle(
                                        color: isPresent ? Colors.green.shade800 : Colors.red.shade800,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}