enum UserRole { student, teacher }

class UserModel {
  final String uid;
  final String email;
  final String name;
  final UserRole role;
  final String? rollNumber; // Only applicable for students

  UserModel({
    required this.uid,
    required this.email,
    required this.name,
    required this.role,
    this.rollNumber,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      uid: json['uid'] ?? '',
      email: json['email'] ?? '',
      name: json['name'] ?? '',
      role: json['role'] == 'teacher' ? UserRole.teacher : UserRole.student,
      rollNumber: json['rollNumber'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'email': email,
      'name': name,
      'role': role == UserRole.teacher ? 'teacher' : 'student',
      'rollNumber': rollNumber,
    };
  }
}
