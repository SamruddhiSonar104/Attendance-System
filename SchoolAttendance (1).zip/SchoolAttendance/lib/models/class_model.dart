class ClassModel {
  final String id;
  final String name;
  final String teacherId;
  final String teacherName;
  final List<String> studentIds;
  final String subject;
  final String section;

  ClassModel({
    required this.id,
    required this.name,
    required this.teacherId,
    required this.teacherName,
    required this.studentIds,
    required this.subject,
    required this.section,
  });

  factory ClassModel.fromJson(Map<String, dynamic> json, String id) {
    return ClassModel(
      id: id,
      name: json['name'] ?? '',
      teacherId: json['teacherId'] ?? '',
      teacherName: json['teacherName'] ?? '',
      studentIds: List<String>.from(json['studentIds'] ?? []),
      subject: json['subject'] ?? '',
      section: json['section'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'teacherId': teacherId,
      'teacherName': teacherName,
      'studentIds': studentIds,
      'subject': subject,
      'section': section,
    };
  }
}
