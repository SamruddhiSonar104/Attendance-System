class AttendanceRecord {
  final String id;
  final String classId;
  final String className;
  final DateTime date;
  final List<StudentAttendance> studentAttendances;
  final String teacherId;

  AttendanceRecord({
    required this.id,
    required this.classId,
    required this.className,
    required this.date,
    required this.studentAttendances,
    required this.teacherId,
  });

  factory AttendanceRecord.fromJson(Map<String, dynamic> json, String id) {
    return AttendanceRecord(
      id: id,
      classId: json['classId'] ?? '',
      className: json['className'] ?? '',
      date: json['date'] != null ? DateTime.parse(json['date']) : DateTime.now(),
      studentAttendances: json['studentAttendances'] != null
          ? List<StudentAttendance>.from(
              json['studentAttendances'].map(
                (x) => StudentAttendance.fromJson(x),
              ),
            )
          : [],
      teacherId: json['teacherId'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'classId': classId,
      'className': className,
      'date': date.toIso8601String(),
      'studentAttendances': studentAttendances.map((x) => x.toJson()).toList(),
      'teacherId': teacherId,
    };
  }
}

class StudentAttendance {
  final String studentId;
  final String studentName;
  final String rollNumber;
  final bool isPresent;

  StudentAttendance({
    required this.studentId,
    required this.studentName,
    required this.rollNumber,
    required this.isPresent,
  });

  factory StudentAttendance.fromJson(Map<String, dynamic> json) {
    return StudentAttendance(
      studentId: json['studentId'] ?? '',
      studentName: json['studentName'] ?? '',
      rollNumber: json['rollNumber'] ?? '',
      isPresent: json['isPresent'] ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'studentId': studentId,
      'studentName': studentName,
      'rollNumber': rollNumber,
      'isPresent': isPresent,
    };
  }

  StudentAttendance copyWith({
    String? studentId,
    String? studentName,
    String? rollNumber,
    bool? isPresent,
  }) {
    return StudentAttendance(
      studentId: studentId ?? this.studentId,
      studentName: studentName ?? this.studentName,
      rollNumber: rollNumber ?? this.rollNumber,
      isPresent: isPresent ?? this.isPresent,
    );
  }
}
