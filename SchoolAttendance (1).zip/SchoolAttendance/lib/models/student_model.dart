class StudentModel {
  final String id;
  final String name;
  final String email;
  final String rollNumber;
  
  StudentModel({
    required this.id,
    required this.name,
    required this.email,
    required this.rollNumber,
  });

  factory StudentModel.fromJson(Map<String, dynamic> json, String id) {
    return StudentModel(
      id: id,
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      rollNumber: json['rollNumber'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'email': email,
      'rollNumber': rollNumber,
    };
  }
}
